const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});
const Player = require('../../../../helper/player.js');
const send = require('../../../../tools/send.js')
const message = context.params.event;
const keyDetails = await lib.utils.kv['@0.1.16'].get({
  key: `${process.env.key}_${message.guild_id}`,
});

if (message.content.startsWith('z!setup')) {
  let channelId = message.content.match(/\d+/g);
  if (!channelId)
    return lib.discord.channels['@0.2.0'].messages.create({
      content: `Please mention the channel where you want to setup music bot.`,
      channel_id: message.channel_id,
    });
  else channelId = channelId[0];

  const msg = await lib.discord.channels['@0.2.0'].messages.create({
    content: `**[ Song List]**\nJoin a voice channel and queue songs by name or url in here.`,
    channel_id: channelId,
    embed: {
      title: `Invite | ZroMusic 😎`,
      url: `https://discord.com/oauth2/authorize?client_id=924259785925345300&scope=applications.commands%20bot&permissions=8`,
      description: `This is the music bot, created by \`JIE ZrosiX#9640\` in Autocode.`,
      color: 0x000000,
      image: {
        url: 'https://media.discordapp.net/attachments/942485840125395014/943527551178010684/standard_2.gif',
      },
      thumbnail: {
        url: 'https://media.discordapp.net/attachments/942485840125395014/943526923559116930/60b357b80b53cfabbcc9363096baf39a.png',
      },
    },
  });

  await Player.reset({keyDetails: {channelId, messageId: msg.id}});

  await lib.utils.kv['@0.1.16'].set({
    key: `${process.env.key}_${message.guild_id}`,
    value: {channelId, messageId: msg.id},
  });

  await lib.discord.channels['@0.2.0'].messages.create({
    content: `╰ No Need Put Prefix 🚫, Just put Tittle or url only.. Enjoy!!✨ ╮`,
    channel_id: message.channel_id,
  });
} else if (keyDetails && keyDetails.channelId === message.channel_id) {
  const voice_channel = await lib.utils.kv['@0.1.16'].get({
    key: `voice_${process.env.key}_${message.guild_id}_${message.author.id}`,
  });

  await lib.discord.channels['@0.2.0'].messages.destroy({
    message_id: message.id, // required
    channel_id: message.channel_id, // required
  });

  if (!voice_channel)
    return send("Please join the voice channel first!", { channel_id: context.params.event.channel_id })

  await Player.play(message.content, {
    channel_id: voice_channel.channelId,
    guild_id: message.guild_id,
    keyDetails,
  }).catch(async (err) => {
    console.log(err)
    await send("Unable to play the song, please try again later.", { channel_id: context.params.event.channel_id })
  });
}







